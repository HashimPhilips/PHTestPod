class Validator {
	public func hello() {
		print("hello")
	}
}
